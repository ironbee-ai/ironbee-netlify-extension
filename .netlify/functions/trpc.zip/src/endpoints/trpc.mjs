
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// src/endpoints/trpc.ts
import { createNetlifyTRPCHandler } from "@netlify/sdk/ui/functions/trpc";

// src/server/router.ts
import { TRPCError as TRPCError2 } from "@trpc/server";
import * as z from "zod";

// src/server/trpc.ts
import { initTRPC } from "@trpc/server";
var trpc = initTRPC.context().create();
var router = trpc.router;
var procedure = trpc.procedure;

// src/server/netlify-proof.ts
import { TRPCError } from "@trpc/server";
function requireTeamId(ctx) {
  if (!ctx.teamId) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "teamId is required" });
  }
  return ctx.teamId;
}
function requireSiteId(ctx) {
  if (!ctx.siteId) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "siteId is required" });
  }
  return ctx.siteId;
}
async function proveTeam(ctx) {
  const teamId = requireTeamId(ctx);
  try {
    const account = await ctx.client.getAccount(teamId);
    if (account.id !== teamId) {
      throw new Error("account id mismatch");
    }
    return account;
  } catch (err) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Netlify did not accept this request for the team", cause: err });
  }
}
async function proveSite(ctx) {
  const teamId = requireTeamId(ctx);
  const siteId = requireSiteId(ctx);
  let site;
  try {
    site = await ctx.client.getSite(siteId);
  } catch (err) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Netlify did not accept this request for the site", cause: err });
  }
  if (site.id !== siteId || site.account_id !== void 0 && site.account_id !== teamId) {
    throw new TRPCError({ code: "FORBIDDEN", message: "This site does not belong to the team" });
  }
  return site;
}

// src/lib/ironbee-api.ts
import { createHmac } from "node:crypto";
var SIGNATURE_HEADER = "x-ironbee-signature";
var TIMESTAMP_HEADER = "x-ironbee-timestamp";
var MS_PER_SECOND = 1e3;
var IronbeeApiRoutes = {
  INSTALL: "/netlify/install",
  CONNECTION: "/netlify/connection",
  SITES_LIST: "/netlify/sites/list",
  SITES_ENABLE: "/netlify/sites/enable",
  SITES_HOOK: "/netlify/sites/hook",
  SITES_DISABLE: "/netlify/sites/disable",
  SITES_CONTEXTS: "/netlify/sites/contexts",
  DEPLOY_STATUS: "/netlify/deploy-status",
  UNINSTALL: "/netlify/uninstall"
};
var IronbeeApiError = class extends Error {
  status;
  code;
  constructor(status, code, message) {
    super(message);
    this.name = "IronbeeApiError";
    this.status = status;
    this.code = code;
  }
};
function requiredEnv(name) {
  const value = process.env[name];
  if (value === void 0 || value.length === 0) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}
function signRequest(secret, timestamp, rawBody) {
  return createHmac("sha256", secret).update(`${timestamp}.${rawBody}`).digest("hex");
}
async function callIronbee(route, body) {
  const baseUrl = requiredEnv("IRONBEE_API_BASE_URL").replace(/\/$/, "");
  const secret = requiredEnv("IRONBEE_EXTENSION_SECRET");
  const rawBody = JSON.stringify(body);
  const timestamp = String(Math.floor(Date.now() / MS_PER_SECOND));
  const response = await fetch(`${baseUrl}${route}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      [SIGNATURE_HEADER]: signRequest(secret, timestamp, rawBody),
      [TIMESTAMP_HEADER]: timestamp
    },
    body: rawBody
  });
  const text = await response.text();
  if (!response.ok) {
    let code = null;
    let message = `IronBee answered ${response.status}`;
    try {
      const parsed = JSON.parse(text);
      code = parsed.code ?? null;
      message = parsed.message ?? message;
    } catch {
    }
    throw new IronbeeApiError(response.status, code, message);
  }
  return text.length > 0 ? JSON.parse(text) : {};
}

// src/server/router.ts
var DEPLOY_SUCCEEDED_EVENT = "deploy_created";
var HOOK_TYPE_URL = "url";
var RETURN_URL_MAX = 2048;
function siteInfoFor(site) {
  return {
    ...site.name !== void 0 ? { siteName: site.name } : {},
    ...site.ssl_url !== void 0 ? { siteUrl: site.ssl_url } : site.url !== void 0 ? { siteUrl: site.url } : {},
    ...site.build_settings?.provider !== void 0 ? { repoProvider: site.build_settings.provider } : {},
    ...site.build_settings?.repo_path !== void 0 ? { repoPath: site.build_settings.repo_path } : {},
    ...site.build_settings?.repo_url !== void 0 ? { repoUrl: site.build_settings.repo_url } : {}
  };
}
function relayError(err) {
  if (err instanceof IronbeeApiError) {
    if (err.code === "TEAM_NOT_CONNECTED") {
      throw new TRPCError2({ code: "PRECONDITION_FAILED", message: err.message, cause: err });
    }
    if (err.code === "SITE_NOT_ENABLED") {
      throw new TRPCError2({ code: "NOT_FOUND", message: err.message, cause: err });
    }
    throw new TRPCError2({ code: "BAD_GATEWAY", message: "IronBee could not complete the request", cause: err });
  }
  throw err;
}
var appRouter = router({
  connection: {
    /** Is this team bound to an IronBee account? */
    status: procedure.query(async ({ ctx }) => {
      const team = await proveTeam(ctx);
      try {
        return await callIronbee(IronbeeApiRoutes.CONNECTION, { teamId: team.id });
      } catch (err) {
        return relayError(err);
      }
    }),
    /** Opens the connect holding row on IronBee's side and returns the link the user follows. */
    start: procedure.input(z.object({ returnUrl: z.string().max(RETURN_URL_MAX).optional() })).mutation(async ({ ctx, input }) => {
      const team = await proveTeam(ctx);
      try {
        return await callIronbee(IronbeeApiRoutes.INSTALL, {
          teamId: team.id,
          ...team.slug !== void 0 ? { teamSlug: team.slug } : {},
          ...team.name !== void 0 ? { teamName: team.name } : {},
          ...ctx.user.id !== null ? { installerId: ctx.user.id } : {},
          ...input.returnUrl !== void 0 ? { returnUrl: input.returnUrl } : {}
        });
      } catch (err) {
        return relayError(err);
      }
    }),
    /** Disconnects the team on IronBee's side. Hooks IronBee no longer knows answer 410 and Netlify deletes them. */
    disconnect: procedure.mutation(async ({ ctx }) => {
      const team = await proveTeam(ctx);
      try {
        await callIronbee(IronbeeApiRoutes.UNINSTALL, { teamId: team.id });
      } catch (err) {
        return relayError(err);
      }
      return { ok: true };
    })
  },
  site: {
    /** This project's verification state, or null when it was never enabled. */
    status: procedure.query(async ({ ctx }) => {
      const teamId = requireTeamId(ctx);
      const siteId = requireSiteId(ctx);
      await proveSite(ctx);
      try {
        const list = await callIronbee(IronbeeApiRoutes.SITES_LIST, { teamId });
        return list.sites.find((site) => site.id === siteId) ?? null;
      } catch (err) {
        return relayError(err);
      }
    }),
    /**
     * Enable verification: IronBee mints the webhook key + JWS secret and hands
     * both back once; the hook is created here on the user's token; IronBee is
     * told the hook id. Idempotent for an already-live site (no rotation).
     */
    enable: procedure.input(z.object({ contexts: z.array(z.enum(["production", "deploy-preview", "branch-deploy"])).nullable().optional() })).mutation(async ({ ctx, input }) => {
      const teamId = requireTeamId(ctx);
      const site = await proveSite(ctx);
      let enabled;
      try {
        enabled = await callIronbee(IronbeeApiRoutes.SITES_ENABLE, {
          teamId,
          siteId: site.id,
          ...siteInfoFor(site),
          ...input.contexts !== void 0 ? { contexts: input.contexts } : {}
        });
      } catch (err) {
        return relayError(err);
      }
      if (enabled.alreadyEnabled || enabled.signatureSecret === null) {
        return enabled.site;
      }
      const hook = await ctx.client.createHookBySiteId(site.id, {
        type: HOOK_TYPE_URL,
        event: DEPLOY_SUCCEEDED_EVENT,
        data: { url: enabled.site.webhookUrl, signature_secret: enabled.signatureSecret }
      });
      try {
        await callIronbee(IronbeeApiRoutes.SITES_HOOK, { teamId, siteId: site.id, hookId: hook.id });
      } catch (err) {
        return relayError(err);
      }
      return { ...enabled.site, hookId: hook.id };
    }),
    /** Disable: delete the hook while the token is at hand, then tell IronBee. */
    disable: procedure.mutation(async ({ ctx }) => {
      const teamId = requireTeamId(ctx);
      const site = await proveSite(ctx);
      let current = null;
      try {
        const list = await callIronbee(IronbeeApiRoutes.SITES_LIST, { teamId });
        current = list.sites.find((candidate) => candidate.id === site.id) ?? null;
      } catch (err) {
        return relayError(err);
      }
      if (current?.hookId) {
        try {
          await ctx.client.deleteHook(current.hookId);
        } catch (err) {
          console.warn(`ironbee: could not delete hook ${current.hookId}: ${String(err)}`);
        }
      }
      try {
        await callIronbee(IronbeeApiRoutes.SITES_DISABLE, { teamId, siteId: site.id });
      } catch (err) {
        return relayError(err);
      }
      return { ok: true };
    }),
    /** Which deploy contexts to verify; null restores the default (previews + branch deploys). */
    setContexts: procedure.input(z.object({ contexts: z.array(z.enum(["production", "deploy-preview", "branch-deploy"])).nullable() })).mutation(async ({ ctx, input }) => {
      const teamId = requireTeamId(ctx);
      const site = await proveSite(ctx);
      try {
        await callIronbee(IronbeeApiRoutes.SITES_CONTEXTS, { teamId, siteId: site.id, contexts: input.contexts });
      } catch (err) {
        return relayError(err);
      }
      return { ok: true };
    }),
    /** Re-checks the hook Netlify holds for this site: present, paused, or gone. */
    hookHealth: procedure.query(async ({ ctx }) => {
      const teamId = requireTeamId(ctx);
      const site = await proveSite(ctx);
      let hookId = null;
      try {
        const list = await callIronbee(IronbeeApiRoutes.SITES_LIST, { teamId });
        hookId = list.sites.find((candidate) => candidate.id === site.id)?.hookId ?? null;
      } catch (err) {
        return relayError(err);
      }
      if (hookId === null) {
        return { state: "missing" };
      }
      const hook = await ctx.client.getHook(hookId);
      if (hook === null) {
        return { state: "missing" };
      }
      return { state: hook.disabled === true ? "paused" : "ok", hookId };
    }),
    /** A paused hook (Netlify pauses after repeated failures) is re-enabled on the user's token. */
    resumeHook: procedure.mutation(async ({ ctx }) => {
      const teamId = requireTeamId(ctx);
      const site = await proveSite(ctx);
      let hookId = null;
      try {
        const list = await callIronbee(IronbeeApiRoutes.SITES_LIST, { teamId });
        hookId = list.sites.find((candidate) => candidate.id === site.id)?.hookId ?? null;
      } catch (err) {
        return relayError(err);
      }
      if (hookId === null) {
        throw new TRPCError2({ code: "NOT_FOUND", message: "No hook to resume; enable verification again" });
      }
      const hook = await ctx.client.getHook(hookId);
      if (hook === null) {
        throw new TRPCError2({ code: "NOT_FOUND", message: "The hook no longer exists on Netlify; disable and enable verification to recreate it" });
      }
      await ctx.client.updateHook(hookId, { data: { ...hook.data, url: String(hook.data["url"] ?? "") } });
      return { ok: true };
    })
  },
  deploy: {
    /** The deploy page's panel: what IronBee found for this deploy. */
    status: procedure.input(z.object({ deployId: z.string().min(1) })).query(async ({ ctx, input }) => {
      const teamId = requireTeamId(ctx);
      const site = await proveSite(ctx);
      const deploy = await ctx.client.getDeploy(input.deployId);
      const deploySiteId = deploy?.siteId ?? deploy?.site_id;
      if (deploy === null || deploySiteId !== void 0 && deploySiteId !== site.id) {
        throw new TRPCError2({ code: "FORBIDDEN", message: "This deploy does not belong to the site" });
      }
      try {
        return await callIronbee(IronbeeApiRoutes.DEPLOY_STATUS, {
          teamId,
          siteId: site.id,
          deployId: input.deployId
        });
      } catch (err) {
        return relayError(err);
      }
    })
  }
});

// src/endpoints/trpc.ts
var config = {
  path: ["/api/trpc{/*}?"]
};
var handler = createNetlifyTRPCHandler({
  endpoint: "/api/trpc",
  router: appRouter
});
var trpc_default = handler;
export {
  config,
  trpc_default as default
};
